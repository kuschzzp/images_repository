package com.kusch.demo.controller;

import cn.dev33.satoken.context.SaHolder;
import cn.dev33.satoken.stp.StpUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 自己即是服务端也是客户端
 */
@RestController
public class HomeController {
    // 平台化首页
    @RequestMapping("/home")
    public Object index() {
        // 如果未登录，则先去登录
        if (!StpUtil.isLogin()) {
            return SaHolder.getResponse().redirect("/sso/auth");
        }
        // 拼接各个子系统的地址，格式形如：/sso/auth?redirect=${子系统首页}/sso/login?back=${子系统首页}
        String link1 = "/sso/auth?redirect=http://127.0.0.1:7777/sso/login?back=http://127.0.0.1:7777/";

        // 组织网页结构返回到前端
        String title = "<h2>SSO 平台首页 登陆状态：" + StpUtil.isLogin() + "</h2>";
        String client1 = "<p><a href='" + link1 + "' target='_blank'> 进入Client1系统 </a></p>";

        return title + client1;
    }

    // 自己作为客户端的首页
    @RequestMapping("/")
    public String clientIndex() {
        String str = "<h2>Sa-Token 应用端----</h2>" +
                "<p>当前会话是否登录：" + StpUtil.isLogin() + "</p>" +
                "<p><a href=\"javascript:location.href='/sso/login?back=http://127.0.0.1:7777/home';" +
                "\">登录</a> " +
                "<a href='/sso/logout?back=self'>注销</a></p>";
        return str;
    }
}









