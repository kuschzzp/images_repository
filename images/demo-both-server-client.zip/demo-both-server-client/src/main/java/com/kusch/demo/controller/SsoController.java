package com.kusch.demo.controller;

import cn.dev33.satoken.config.SaSsoConfig;
import cn.dev33.satoken.sso.SaSsoProcessor;
import cn.dev33.satoken.stp.StpUtil;
import cn.dev33.satoken.util.SaResult;
import com.dtflys.forest.Forest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
//formatter:off
/**
 * 即是服务端，又是客户端
 * 前后端分离项目 sso 接口调用流程：
 * - 前端展示 门户系统 页面， 此时处于未登陆状态， 有个登陆按钮，用户点击任何一个按钮均需要去登陆认证
 * -- 登陆按钮链接示例： http://127.0.0.1:7777/sso/login?back=http://127.0.0.1/home
 * -- 访问该链接后，后台将地址重定向到 http://127.0.0.1:7777/sso/auth?redirect=http://127.0.0.1:7777/sso/login?back=http://127.0.0
 * .1/home
 * -- 此时处于未登陆状态，后台会返回错误码，前台需要将页面跳转至 前端编写的登陆页面
 * -- 登陆接口例子：http://127.0.0.1:7777/sso/doLogin?name=账号&pwd=密码
 * -- 登陆成功之后会返回对应的 token
 * -- 此时再次访问 用户点登录 时的页面，即可看到登陆成功
 * <p>
 * -- 应用的地址配置类似于： /sso/auth?redirect=${子系统首页}/sso/login?back=${子系统首页}
 * -- 在门户页面直接点击链接可直接成为登陆状态
 */
//formatter:on
@RestController
public class SsoController {

    // 处理 SSO-Server 端所有请求 
    @RequestMapping({"/sso/auth", "/sso/doLogin", "/sso/checkTicket", "/sso/signout"})
    public Object ssoServerRequest() {
        return SaSsoProcessor.instance.serverDister();
    }

    // 处理 SSO-Client 端所有请求 
    @RequestMapping({"/sso/login", "/sso/logout", "/sso/logoutCall"})
    public Object ssoClientRequest() {
        return SaSsoProcessor.instance.clientDister();
    }

    // 配置SSO相关参数 
    @Autowired
    private void configSso(SaSsoConfig sso) {
        // 配置：未登录时返回的View
        sso.setNotLoginView(() -> {
            //                        String msg = "来自于SsoServerController  当前会话在SSO-Server端尚未登录，请先访问"
            //                                + "<a href='/sso/doLogin?name=sa&pwd=123456' target='_blank'> doLogin登录
            //                                </a>"
            //                                + "进行登录之后，刷新页面开始授权";
            //                        return msg;

            //前后端分离的话，这项操作在前端进行判断，也可以为了防止直接访问对应接口，在这里打印一段提示，让其走前端页面访问
            //登陆直接返回 登陆页面
                        return new ModelAndView("sa-login.html");
//            return SaResult.error("请先登陆，模拟登陆，浏览器直接敲：http://127.0.0.1:7777/sso/doLogin?name=sa&pwd=123456 ");
        });

        // 配置：登录处理函数
        sso.setDoLoginHandle((name, pwd) -> {
            // 此处仅做模拟登录，真实环境应该查询数据进行登录
            if ("sa".equals(name) && "123456".equals(pwd)) {
                StpUtil.login(10001);
                System.out.println("登陆成功：token是：" + StpUtil.getTokenInfo());
                return SaResult.ok("登录成功！").setData(StpUtil.getTokenValue());
            }
            return SaResult.error("登录失败！");
        });

        // 配置 Http 请求处理器 （在模式三的单点注销功能下用到，如不需要可以注释掉）
        sso.setSendHttp(url -> {
            try {
                // 发起 http 请求
                System.out.println("模式三的单点注销功能下用到------ 发起请求：" + url);
                return Forest.get(url).executeAsString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        });
    }

}
